﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SimpleHttp
{
    class LogHandling
    {
    }
    public sealed class mainLogSingleton
    {
        private static volatile mainLogSingleton instance;
        private static object syncRoot = new Object();
        static Form1 frm;

        private mainLogSingleton() { }

        public static mainLogSingleton Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new mainLogSingleton();
                    }
                }
                return instance;
            }
        }

        public void SetForm(Form1 frm1)
        {
            frm = frm1;
        }

        private delegate void myDelegate2(String str);
        private void updateProgress2(String str)
        {
            //Console.WriteLine("1 : " + theValue.ToString());
            frm.lbMainLog.Items.Add(str);
            frm.lbMainLog.SetSelected(frm.lbMainLog.Items.Count - 1, true);
        }

        public void addResponse(object[] obj)
        {
            //string data = obj[0].ToString();
            //if (data.IndexOf("&") > -1)
            //{
            //    string[] data2 = data.Split('\n');
            //    string d = data2[data2.Length - 1];
            //    NameValueCollection qscoll = HttpUtility.ParseQueryString(d);

            //    if (qscoll["ALIVE"] != null && qscoll["ALIVE"] == "IAM")
            //        if (!this.db.exists("phoneNumber", qscoll["PHONE_SERIAL_NUMBER"]))
            //            this.db.write("phoneNumber", qscoll["PHONE_SERIAL_NUMBER"], qscoll["PHONE_NUMBER"]);
            //}

            //frm.Invoke(new myDelegate2(updateProgress2), new object[] { 1, 100 });
            frm.Invoke(new myDelegate2(updateProgress2), obj[0]);
        }
    }
}
