﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimpleHttp
{
    public partial class Form1 : Form
    {
        Threads thd;
        bool btStartAndStop=true;
        HttpServerMain hsm;

        mainLogSingleton mls;

        Util util;

        public Form1()
        {
            InitializeComponent();
            thd = new Threads(this);
            hsm = new HttpServerMain();

            mls = mainLogSingleton.Instance;
            mls.SetForm(this);

            util = Util.Instance;
        }

        private void evLoad(object sender, EventArgs e)
        {
            tbLocalIp.Text = util.CLIENTIP;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //HttpServer
            
            if (btStartAndStop)
            {
                thd.ThreadStart();
                button1.Text = "중지";
                btStartAndStop = !btStartAndStop;

                //HttpServerMain 포트 넣어서 웹서버 돌림 포트는 이론상 0~65535
                hsm.Start(int.Parse(tbPort.Text));

                tbPort.ReadOnly = true;
            }
            else
            {
                thd.ThreadStop(false);
                button1.Text = "시작";
                btStartAndStop = !btStartAndStop;

                hsm.Stop();

                tbPort.ReadOnly = false;
            }

        }

        private void Form1Closing(object sender, FormClosingEventArgs e)
        {
            if (!btStartAndStop)
            {
                thd.ThreadStop(true);
                button1.Name = "시작";

                hsm.Stop();
            }
        }

        private void evKeyPress_PortFilter(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true; 
            }            
        }

        
    }
}
