﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace SimpleHttp
{
    public class Threads
    {
        Thread th1;
        Thread th2;
        Thread th3;
        Form1 frm;
        bool bth1;

        public Threads(Form1 frm)
        {
            this.frm = frm;
        }


        // progress bar
        private delegate void myDelegate(int theValue, int theMax);
        private void updateProgress(int theValue, int theMax)
        {
            if (theMax != 0)
                frm.progressBar1.Maximum = theMax;
            if (theValue > theMax)
                theValue = theMax;
            if (theValue < 0)
                theValue = 0;
            frm.progressBar1.Value = theValue;
        }
        

        private void myThread()
        {
            for (int i = 0, j = 20, k = 1;;)
            {
                while (bth1)
                {
                    if (frm.progressBar1.InvokeRequired)
                    {
                        frm.Invoke(new myDelegate(updateProgress), new object[] { i+=k, j });
                        Thread.Sleep(100);
                    }
                    if (i > j+3 || i < 1)
                        k*=-1;
                }
                i = 0;
                if (frm.progressBar1.InvokeRequired)
                {
                    frm.Invoke(new myDelegate(updateProgress), new object[] { i, j });
                }
                break;
            }
        }



        // Th2

        private delegate void myDelegate2(int theValue, int theMax, Form1 frm);
        private void updateProgress2(int theValue, int theMax, Form1 frm)
        {
            //Console.WriteLine("1 : " + theValue.ToString());
            frm.lbMainLog.Items.Add(theValue.ToString());
            frm.lbMainLog.SetSelected(frm.lbMainLog.Items.Count - 1, true);
        }

        private void myThread2(Form1 frm)
        {
            for (int i = 0; i < 100; i++)
            {
                frm.Invoke(new myDelegate2(updateProgress2), new object[] { i, 100 }, frm);
                Thread.Sleep(100);
            }
            //th2.Abort();
        }


        // Th3
        private delegate void myDelegate3(int theValue, int theMax, Form1 frm);
        private void updateProgress3(int theValue, int theMax, Form1 frm)
        {
            //Console.WriteLine("2 : " + theValue.ToString());
            frm.lbMainLog.Items.Add("2 > " + theValue.ToString());
            frm.lbMainLog.SetSelected(frm.lbMainLog.Items.Count - 1, true);
        }

        private void myThread3(Form1 frm)
        {
            for (int i = 0; i < 100; i += 2)
            {
                frm.Invoke(new myDelegate2(updateProgress3), new object[] { i, 50 }, frm);
                Thread.Sleep(80);
            }
            //th1.Abort();
        }



        public void ThreadStart()
        {
            th1 = new Thread(new ThreadStart(myThread));
            //th2 = new Thread(new ThreadStart(myThread2));
            //th3 = new Thread(new ThreadStart(myThread3));
            bth1 = true;
            th1.Start();
            //th2.Start();
            //th3.Start();


        }

        public void ThreadStop(bool closing)
        {
            if (closing)
                th1.Abort();
            bth1 = false;
        }
    }    
}
