﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleHttp
{
    //class Database
    //{
    //    private string dir;

    //    public Database()
    //    {
    //        this.dir = Path.Combine(Environment.CurrentDirectory, "data");

    //        if (!Directory.Exists(this.dir))
    //            Directory.CreateDirectory(this.dir);

    //        this.createCategory("phoneNumber");
    //    }

    //    public void createCategory(string category)
    //    {
    //        if (!Directory.Exists(this.dir + @"\" + category))
    //            Directory.CreateDirectory(this.dir + @"\" + category);
    //    }

    //    public void deleteCategory(string category)
    //    {
    //        if (Directory.Exists(this.dir + @"\" + category))
    //            Directory.Delete(this.dir + @"\" + category, true);
    //    }

    //    public bool exists(string category, string key)
    //    {
    //        return Directory.Exists(this.dir + @"\" + category + @"\" + key);
    //    }

    //    public void write(string category, string key, string value)
    //    {
    //        StreamWriter writer = new StreamWriter(this.dir + @"\" + category + @"\" + key+".txt");
    //        //\r\n
    //        writer.Write(value + System.Environment.NewLine + value);
    //        //writer.W
    //        writer.Close();
    //    }

    //    public string read(string category, string key)
    //    {
    //        StreamReader reader = new StreamReader(this.dir + @"\" + category + @"\" + key);
    //        string value = reader.ReadToEnd();
            
    //        reader.Close();

    //        return value;
    //    }

    //    public void delete(string category, string key)
    //    {
    //        File.Delete(this.dir + @"\" + category + @"\" + key);
    //    }
    //}
}
