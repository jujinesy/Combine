﻿using System;
using System.Data.SqlServerCe;

//using System.Collections.Generic;
//using System.Text;
//Path 쓸려고
using System.IO;

namespace SimpleHttp
{
    //class Database
    //{
    //    private string dir;

    //    public Database()
    //    {
    //        this.dir = Path.Combine(Environment.CurrentDirectory, "data");

    //        if (!Directory.Exists(this.dir))
    //            Directory.CreateDirectory(this.dir);

    //        this.createCategory("phoneNumber");
    //    }

    //    public void createCategory(string category)
    //    {
    //        if (!Directory.Exists(this.dir + @"\" + category))
    //            Directory.CreateDirectory(this.dir + @"\" + category);
    //    }

    //    public void deleteCategory(string category)
    //    {
    //        if (Directory.Exists(this.dir + @"\" + category))
    //            Directory.Delete(this.dir + @"\" + category, true);
    //    }

    //    public bool exists(string category, string key)
    //    {
    //        return Directory.Exists(this.dir + @"\" + category + @"\" + key);
    //    }

    //    public void write(string category, string key, string value)
    //    {
    //        StreamWriter writer = new StreamWriter(this.dir + @"\" + category + @"\" + key+".txt");
    //        //\r\n
    //        writer.Write(value + System.Environment.NewLine + value);
    //        //writer.W
    //        writer.Close();
    //    }

    //    public string read(string category, string key)
    //    {
    //        StreamReader reader = new StreamReader(this.dir + @"\" + category + @"\" + key);
    //        string value = reader.ReadToEnd();

    //        reader.Close();

    //        return value;
    //    }

    //    public void delete(string category, string key)
    //    {
    //        File.Delete(this.dir + @"\" + category + @"\" + key);
    //    }
    //}

    public class Database
    {
        private static string connString = @"Data Source=|DataDirectory|\DB.sdf";
        //private static volatile Database instance;
        //private static object syncRoot = new Database();
        
        //private Database() { }

        //public static Database Instance
        //{
        //    get
        //    {
        //        if (instance == null)
        //        {
        //            lock (syncRoot)
        //            {
        //                if (instance == null)
        //                    instance = new Database();
        //            }
        //        }
        //        return instance;
        //    }
        //}

        private Database()
        {
        }

        public static Database Instance { get { return Nested.instance; } }

        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly Database instance = new Database();
        }


        public bool insert_phoneinfo(object[] obj)
        {
            string sql =
                "INSERT INTO phone ([SERIAL_NUMBER], [NUMBER], [NUMBER_CHANGE_COUNT], [PAYMENT_COUNT], [LEFT_CHARGE], [ORDER]) " +
            "VALUES (@SERIAL_NUMBER, @NUMBER, @NUMBER_CHANGE_COUNT, @PAYMENT_COUNT, @LEFT_CHARGE, @ORDER)";
            //string sql =
            //    "INSERT INTO phone ([SERIAL_NUMBER], [NUMBER]) " +
            //"VALUES (@SERIAL_NUMBER, @NUMBER)";
            SqlCeConnection conn = new SqlCeConnection(connString);
            SqlCeCommand cmd = new SqlCeCommand(sql, conn);
            conn.Open();

            SqlCeTransaction tran = conn.BeginTransaction();
            cmd.Transaction = tran;
            cmd.Parameters.Add("@SERIAL_NUMBER", obj[0].ToString());
            cmd.Parameters.Add("@NUMBER", obj[1].ToString());
            cmd.Parameters.AddWithValue("@NUMBER_CHANGE_COUNT", 0);
            cmd.Parameters.AddWithValue("@PAYMENT_COUNT", 0);
            cmd.Parameters.AddWithValue("@LEFT_CHARGE", 0);
            cmd.Parameters.AddWithValue("@ORDER", 0);
            //cmd.Parameters.Add("@NUMBER_CHANGE_COUNT", (Int32)1);
            //cmd.Parameters.Add("@PAYMENT_COUNT", (Int32)1);
            //cmd.Parameters.Add("@LEFT_CHARGE", (Int32)1);
            //cmd.Parameters.Add("@ORDER", (Int32)1);

            try
            {
                cmd.ExecuteNonQuery();
                tran.Commit();
            }
            finally
            {
                conn.Close();
            }

            return true;
        }

        public string select_getphonenumber(string serial_number)
        {
            string query = "SELECT [NUMBER] FROM phone WHERE [SERIAL_NUMBER] = @serial_number";

            SqlCeConnection conn = new SqlCeConnection(connString);
            SqlCeCommand cmd = new SqlCeCommand(query, conn);
            conn.Open();

            cmd.Parameters.Add("@serial_number", serial_number);
            SqlCeDataReader rdr = cmd.ExecuteReader();
            try
            {
                //newProdID = (Int32)cmd.ExecuteScalar();
                while (rdr.Read())
                {
                    return rdr.GetString(0);
                }
            }
            finally
            {
                // Always call Close when done reading
                //
                rdr.Close();

                // Always call Close when done reading
                //
                conn.Close();
            }



            return "";

        }

        public bool select_lvinit()
        {
            //string query = "SELECT [Order ID], [Customer] FROM Orders";
            string query = "SELECT * FROM phone order by [ORDER]";
            SqlCeConnection conn = new SqlCeConnection(connString);
            SqlCeCommand cmd = new SqlCeCommand(query, conn);

            conn.Open();
            SqlCeDataReader rdr = cmd.ExecuteReader();


            Form1.Instance.listView1.Items.Clear();

            
            try
            {
                // Iterate through the results
                //
                
                while (rdr.Read())
                {
                    //newList.SubItems.Add(DateTime.Now.ToLongTimeString());
                    //int val1 = rdr.GetInt32(0);
                    //string val2 = rdr.GetString(1);
                    System.Windows.Forms.ListViewItem newList = new System.Windows.Forms.ListViewItem(rdr.GetInt32(0).ToString());
                    newList.SubItems.Add("접속 대기");
                    
                    newList.SubItems.Add(rdr.GetString(1));
                    if (!rdr.IsDBNull(2))
                        newList.SubItems.Add(rdr.GetString(2));
                    if (!rdr.IsDBNull(3))
                        newList.SubItems.Add(rdr.GetInt32(3).ToString());
                    if (!rdr.IsDBNull(4))
                        newList.SubItems.Add(rdr.GetInt32(4).ToString());
                    if (!rdr.IsDBNull(5))
                        newList.SubItems.Add(rdr.GetInt32(5).ToString());
                    Form1.Instance.listView1.Items.Add(newList);
                }
            }
            finally
            {
                // Always call Close when done reading
                //
                rdr.Close();

                // Always call Close when done reading
                //
                conn.Close();
            }

            return true;
        }

        


        public bool update_phonenumber(object[] obj)
        {
            //string sql =
            //    "INSERT INTO phone ([SERIAL_NUMBER], [NUMBER], [NUMBER_CHANGE_COUNT], [PAYMENT_COUNT], [LEFT_CHARGE], [ORDER]) " +
            //"VALUES (@SERIAL_NUMBER, @NUMBER, @NUMBER_CHANGE_COUNT, @PAYMENT_COUNT, @LEFT_CHARGE, @ORDER)";
            int result=-1;
            string sql = "UPDATE phone SET [NUMBER] = @NUMBER, [NUMBER_CHANGE_COUNT] = [NUMBER_CHANGE_COUNT]+1 WHERE [SERIAL_NUMBER]=@SERIAL_NUMBER";
            SqlCeConnection conn = new SqlCeConnection(connString);
            SqlCeCommand cmd = new SqlCeCommand(sql, conn);
            conn.Open();

            SqlCeTransaction tran = conn.BeginTransaction();
            cmd.Transaction = tran;
            cmd.Parameters.Add("@NUMBER", obj[0].ToString());
            cmd.Parameters.Add("@SERIAL_NUMBER", obj[1].ToString());
            //cmd.Parameters.AddWithValue("@NUMBER_CHANGE_COUNT", 0);
            //cmd.Parameters.Add("@NUMBER_CHANGE_COUNT", (Int32)1);
            //cmd.Parameters.Add("@PAYMENT_COUNT", (Int32)1);
            //cmd.Parameters.Add("@LEFT_CHARGE", (Int32)1);
            //cmd.Parameters.Add("@ORDER", (Int32)1);

            try
            {
                result = cmd.ExecuteNonQuery();
                tran.Commit();
            }
            finally
            {
                conn.Close();
            }

            if (result > 0)
                return true;
            return false;
        }




        public void test()
        {
            string dir = Path.Combine(Environment.CurrentDirectory, "DB.sdf");
            string connectionString = @"Data Source=|DataDirectory|\DB.sdf";
            //string connectionString = @dir;

            SqlCeConnection con = new SqlCeConnection(connectionString);
            con.Open();

            // 데이터베이스 커맨드 생성 
            SqlCeCommand cmd = new SqlCeCommand();

            // 커맨드에 커넥션을 연결 
            cmd.Connection = con;

            // 트랜잭션 생성 
            SqlCeTransaction tran = con.BeginTransaction();
            cmd.Transaction = tran;
            // 쿼리 생성 : Insert 쿼리 
            cmd.CommandText = "INSERT INTO Test VALUES('소녀시대')";

            // 쿼리 실행 
            cmd.ExecuteNonQuery();

            // 반복으로 몇개 더 넣어보겠습니다. 
            cmd.CommandText = "INSERT INTO Test VALUES('원더걸스')";
            cmd.ExecuteNonQuery();

            cmd.CommandText = "INSERT INTO Test VALUES('카라')";
            cmd.ExecuteNonQuery();

            // 커밋 
            tran.Commit();

            // SELECT 쿼리로 변경 
            cmd.CommandText = "SELECT * FROM Test";

            // DataReader에 쿼리 결과값 저장 
            SqlCeDataReader reader = cmd.ExecuteReader();

            // 결과값 출력 
            while (reader.Read())
            {
                Console.WriteLine(reader["Name"]);
            }

            con.Close();
        }
    }





//    static void Read()
//{
//    try
//    {
//        string connectionString =
//            "server=.;" +
//            "initial catalog=employee;" +
//            "user id=sa;" +
//            "password=sa123";
//        using (SqlConnection conn =
//            new SqlConnection(connectionString))
//        {
//            conn.Open();
//            using (SqlCommand cmd =
//                new SqlCommand("SELECT * FROM EmployeeDetails", conn))
//            {
//                SqlDataReader reader = cmd.ExecuteReader();

//                if (reader.HasRows)
//                {
//                    while (reader.Read())
//                    {
//                        Console.WriteLine("Id = ", reader["Id"]);
//                        Console.WriteLine("Name = ", reader["Name"]);
//                        Console.WriteLine("Address = ", reader["Address"]);
//                    }
//                }

//                reader.Close();
//            }
//        }
//    }
//    catch (SqlException ex)
//    {
//        //Log exception
//        //Display Error message
//    }
//}

//static void Insert()
//{
//    try
//    {
//        string connectionString =
//            "server=.;" +
//            "initial catalog=employee;" +
//            "user id=sa;" +
//            "password=sa123";
//        using (SqlConnection conn =
//            new SqlConnection(connectionString))
//        {
//            conn.Open();
//            using (SqlCommand cmd =
//                new SqlCommand("INSERT INTO EmployeeDetails VALUES(" +
//                    "@Id, @Name, @Address)", conn))
//            {
//                cmd.Parameters.AddWithValue("@Id", 1);
//                cmd.Parameters.AddWithValue("@Name", "Amal Hashim");
//                cmd.Parameters.AddWithValue("@Address", "Bangalore");

//                int rows = cmd.ExecuteNonQuery();

//                //rows number of record got inserted
//            }
//        }
//    }
//    catch (SqlException ex)
//    {
//        //Log exception
//        //Display Error message
//    }
//}

//static void Update()
//{
//    try
//    {
//        string connectionString =
//            "server=.;" +
//            "initial catalog=employee;" +
//            "user id=sa;" +
//            "password=sa123";
//        using (SqlConnection conn =
//            new SqlConnection(connectionString))
//        {
//            conn.Open();
//            using (SqlCommand cmd =
//                new SqlCommand("UPDATE EmployeeDetails SET Name=@NewName, Address=@NewAddress" +
//                    " WHERE Id=@Id", conn))
//            {
//                cmd.Parameters.AddWithValue("@Id", 1);
//                cmd.Parameters.AddWithValue("@Name", "Munna Hussain");
//                cmd.Parameters.AddWithValue("@Address", "Kerala");

//                int rows = cmd.ExecuteNonQuery();

//                //rows number of record got updated
//            }
//        }
//    }
//    catch (SqlException ex)
//    {
//        //Log exception
//        //Display Error message
//    }
//}

//static void Delete()
//{
//    try
//    {
//        string connectionString =
//            "server=.;" +
//            "initial catalog=employee;" +
//            "user id=sa;" +
//            "password=sa123";
//        using (SqlConnection conn =
//            new SqlConnection(connectionString))
//        {
//            conn.Open();
//            using (SqlCommand cmd =
//                new SqlCommand("DELETE FROM EmployeeDetails " +
//                    "WHERE Id=@Id", conn))
//            {
//                cmd.Parameters.AddWithValue("@Id", 1);
                
//                int rows = cmd.ExecuteNonQuery();

//                //rows number of record got deleted
//            }
//        }
//    }
//    catch (SqlException ex)
//    {
//        //Log exception
//        //Display Error message
//    }
//}
    //public void insert()
    //{
    //    string query = "SELECT [Order ID], [Customer] FROM Orders";
    //    SqlCeConnection conn = new SqlCeConnection(connString);
    //    SqlCeCommand cmd = new SqlCeCommand(query, conn);

    //    conn.Open();
    //    SqlCeDataReader rdr = cmd.ExecuteReader();

    //    try
    //    {
    //        // Iterate through the results
    //        //
    //        while (rdr.Read())
    //        {
    //            int val1 = rdr.GetInt32(0);
    //            string val2 = rdr.GetString(1);
    //        }
    //    }
    //    finally
    //    {
    //        // Always call Close when done reading
    //        //
    //        rdr.Close();

    //        // Always call Close when done reading
    //        //
    //        conn.Close();
    //    }
    //}


//    static public int AddProductCategory(string newName, string connString)
//{
//    Int32 newProdID = 0;
//    string sql =
//        "INSERT INTO Production.ProductCategory (Name) VALUES (@Name); "
//        + "SELECT CAST(scope_identity() AS int)";
//    using (SqlConnection conn = new SqlConnection(connString))
//    {
//        SqlCommand cmd = new SqlCommand(sql, conn);
//        cmd.Parameters.Add("@Name", SqlDbType.VarChar);
//        cmd.Parameters["@name"].Value = newName;
//        try
//        {
//            conn.Open();
//            newProdID = (Int32)cmd.ExecuteScalar();
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine(ex.Message);
//        }
//    }
//    return (int)newProdID;
//}
}
