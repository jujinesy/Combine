﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Web;
using System.Text.RegularExpressions;

namespace SimpleHttp
{
    class LogHandling
    {
    }
    public sealed class mainLogSingleton
    {
        //private static volatile mainLogSingleton instance;
        //private static object syncRoot = new Object();

        //private mainLogSingleton() { }

        //public static mainLogSingleton Instance
        //{
        //    get
        //    {
        //        if (instance == null)
        //        {
        //            lock (syncRoot)
        //            {
        //                if (instance == null)
        //                    instance = new mainLogSingleton();
        //            }
        //        }
        //        return instance;
        //    }
        //}

        private mainLogSingleton()
        {
        }

        public static mainLogSingleton Instance { get { return Nested.instance; } }

        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly mainLogSingleton instance = new mainLogSingleton();
        }







        private delegate void myDelegate2(object[] obj);
        private void updateProgress2(object[] obj)
        {
            
            StringBuilder sb = new StringBuilder();
            //Console.WriteLine("1 : " + theValue.ToString());
            //Form1.Instance.lbMainLog.Items.Add(str);
            //Console.Write("{0} ", score);            
            //foreach (string str in obj) // foreach(데이터형_변수 in 배열 이름)
            //{
            //    sb.Append(str);
            //}

            


            if (Form1.Instance.lbMainLog.Items.Count == Conf.lbMainLog)
                Form1.Instance.lbMainLog.Items.Clear();
            for (int i = 0; i < obj.Length ; i++)
            {
                sb.Append(obj[i].ToString());
            }
            Form1.Instance.lbMainLog.Items.Add(sb.ToString());
            //Form1.Instance.lbMainLog.Items.Add(obj[0]);
            Form1.Instance.lbMainLog.SetSelected(Form1.Instance.lbMainLog.Items.Count - 1, true);
        }

        public void addResponse(object[] obj)
        {
            string data = obj[0].ToString();
            if (data.Equals("POST data"))
            {
                //string[] data2 = obj[2].ToString().Split('\n');
                //string dataSplit = data2[data2.Length - 1];
                //NameValueCollection qscoll = HttpUtility.ParseQueryString(dataSplit);
                NameValueCollection qscoll = HttpUtility.ParseQueryString(obj[2].ToString());
                if (qscoll["HTTP_URL"] == "ALIVE")
                {
                    if (!Database.Instance.select_getphonenumber(qscoll["PHONE_SERIAL_NUMBER"]).Equals(qscoll["PHONE_NUMBER"]))
                    {
                        if (!Database.Instance.update_phonenumber(new object[] { qscoll["PHONE_NUMBER"], qscoll["PHONE_SERIAL_NUMBER"] }))
                            Database.Instance.insert_phoneinfo(new object[] { qscoll["PHONE_SERIAL_NUMBER"], qscoll["PHONE_NUMBER"] });
                        Database.Instance.select_lvinit();
                    }
                    Uimanage.Instance.lvPhoneConnectTimeUpdate(qscoll["PHONE_SERIAL_NUMBER"]);                    //if (Database.Instance.select_getphonenumber(qscoll["PHONE_SERIAL_NUMBER"]).Equals(""))
                    //{
                    //    if (!Uimanage.Instance.getlvphonenumber(qscoll["PHONE_SERIAL_NUMBER"]).Equals(qscoll["PHONE_NUMBER"]))
                    //    {
                    //    }
                    //}
                    //else
                    //{
                    //    Database.Instance.insert_phoneinfo(new object[] { qscoll["PHONE_SERIAL_NUMBER"], qscoll["PHONE_NUMBER"] });
                    //    Database.Instance.select_lvinit();
                    //}
                    //Uimanage.Instance.lvPhoneConnectTimeUpdate(qscoll["PHONE_SERIAL_NUMBER"]);
                }
                else if(qscoll["HTTP_URL"] == "SMS")
                {
                    if (qscoll["CONTENTS"].Substring(0, 5).Equals("승인번호[") && qscoll["CONTENTS"].Substring(qscoll["CONTENTS"].Length - 5).Equals("[한게임]"))
                    {
                        //요금
                         //   string c = System.Text.RegularExpressions.Regex.Replace(qscoll["CONTENTS"].Substring(11), @"\D", "");
                        //스레드 큐
                    }
                }
            }
            else if (data.Equals("POST dddata"))
            {
            }


            
            //if (data.IndexOf("&") > -1)
            //{
            //    string[] data2 = data.Split('\n');
            //    string d = data2[data2.Length - 1];
            //    NameValueCollection qscoll = HttpUtility.ParseQueryString(d);

            //    if (qscoll["ALIVE"] != null && qscoll["ALIVE"] == "IAM")
            //        if (!this.db.exists("phoneNumber", qscoll["PHONE_SERIAL_NUMBER"]))
            //            this.db.write("phoneNumber", qscoll["PHONE_SERIAL_NUMBER"], qscoll["PHONE_NUMBER"]);
            //}

            //frm.Invoke(new myDelegate2(updateProgress2), new object[] { 1, 100 });
            Form1.Instance.Invoke(new myDelegate2(updateProgress2), new object[] { obj });

            
        }
    }
}
