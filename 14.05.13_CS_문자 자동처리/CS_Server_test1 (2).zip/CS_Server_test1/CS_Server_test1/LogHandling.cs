﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SimpleHttp
{
    class LogHandling
    {
    }
    public sealed class mainLogSingleton
    {
        private static volatile mainLogSingleton instance;
        private static object syncRoot = new Object();

        private mainLogSingleton() { }

        public static mainLogSingleton Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new mainLogSingleton();
                    }
                }
                return instance;
            }
        }

        private delegate void myDelegate2(object[] obj);
        private void updateProgress2(object[] obj)
        {
            //Console.WriteLine("1 : " + theValue.ToString());
            //Form1.Instance.lbMainLog.Items.Add(str);
            //Console.Write("{0} ", score);
            StringBuilder sb = new StringBuilder();
            //foreach (string str in obj) // foreach(데이터형_변수 in 배열 이름)
            //{
            //    sb.Append(str);
            //}
            for (int i = 0; i < obj.Length ; i++)
            {
                sb.Append(obj[i].ToString());
            }
            Form1.Instance.lbMainLog.Items.Add(sb.ToString());
            //Form1.Instance.lbMainLog.Items.Add(obj[0]);
            Form1.Instance.lbMainLog.SetSelected(Form1.Instance.lbMainLog.Items.Count - 1, true);
        }

        public void addResponse(object[] obj)
        {
            string data = obj[0].ToString();
            //if (data.IndexOf("&") > -1)
            //{
            //    string[] data2 = data.Split('\n');
            //    string d = data2[data2.Length - 1];
            //    NameValueCollection qscoll = HttpUtility.ParseQueryString(d);

            //    if (qscoll["ALIVE"] != null && qscoll["ALIVE"] == "IAM")
            //        if (!this.db.exists("phoneNumber", qscoll["PHONE_SERIAL_NUMBER"]))
            //            this.db.write("phoneNumber", qscoll["PHONE_SERIAL_NUMBER"], qscoll["PHONE_NUMBER"]);
            //}

            //frm.Invoke(new myDelegate2(updateProgress2), new object[] { 1, 100 });
            //Form1.Instance.Invoke(new myDelegate2(updateProgress2), new object[] { obj });

            if( data.Equals("POST data") )
            {
                //string[] data2 = obj[2].ToString().Split('\n');
                //string dataSplit = data2[data2.Length - 1];
                //NameValueCollection qscoll = HttpUtility.ParseQueryString(dataSplit);
                NameValueCollection qscoll = HttpUtility.ParseQueryString(obj[2].ToString());
                if (qscoll["HTTP_URL"] == "ALIVE")
                {
                    if (Database.Instance.select_phoneserial(qscoll["PHONE_SERIAL_NUMBER"]))
                    {
                        Form1.Instance.Invoke(new myDelegate2(updateProgress2), new object[] { obj });
                        Uimanage.Instance.lvPhoneConnectTimeUpdate(qscoll["PHONE_SERIAL_NUMBER"]);
                    }
                    else
                    {
                        Database.Instance.insert_phoneinfo(new object[] { qscoll["PHONE_SERIAL_NUMBER"], qscoll["PHONE_NUMBER"] });
                        Uimanage.Instance.lvPhoneConnectTimeUpdate(qscoll["PHONE_SERIAL_NUMBER"]);
                    }
                }
                else
                {
                }
            } else if( data.Equals("POST dddata") )
            {
            }
        }
    }
}
