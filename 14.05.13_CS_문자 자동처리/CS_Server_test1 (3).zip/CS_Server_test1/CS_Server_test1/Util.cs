﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace SimpleHttp
{
    public class Util
    {
        //private static volatile Util instance;
        //private static object syncRoot = new Object();
        //private Util() { }

        //public static Util Instance
        //{
        //    get
        //    {
        //        if (instance == null)
        //        {
        //            lock (syncRoot)
        //            {
        //                if (instance == null)
        //                    instance = new Util();
        //            }
        //        }
        //        return instance;
        //    }
        //}

        private Util()
        {
        }

        public static Util Instance { get { return Nested.instance; } }

        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly Util instance = new Util();
        }





        public string getclientIp
        {
            get
            {
                System.Net.IPHostEntry host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName());
                string clientIP = string.Empty;
                for (int i = 0; i < host.AddressList.Length; i++)
                {
                    // AddressFamily.InterNetworkV6 - IPv6
                    if (host.AddressList[i].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        clientIP = host.AddressList[i].ToString();
                    }
                }
                return clientIP;
            }
        }
    }

    public class Conf
    {
        //private static volatile Conf instance;
        //private static object syncRoot = new Object();
        //private Conf() { }

        //public static Conf Instance
        //{
        //    get
        //    {
        //        if (instance == null)
        //        {
        //            lock (syncRoot)
        //            {
        //                if (instance == null)
        //                    instance = new Conf();
        //            }
        //        }
        //        return instance;
        //    }
        //}


        private Conf()
        {
        }

        public static Conf Instance { get { return Nested.instance; } }

        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly Conf instance = new Conf();
        }


        public static int lbMainLog = 500;
    }
}
