﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimpleHttp
{
    public partial class Form1 : Form
    {
        static bool btStartAndStop = true;


        //private static volatile Form1 instance;
        //private static object syncRoot = new Form1();
        //private Form1() {
        //    InitializeComponent();
        //}

        //public static Form1 Instance
        //{
        //    get
        //    {
        //        if (instance == null)
        //        {
        //            lock (syncRoot)
        //            {
        //                if (instance == null)
        //                    instance = new Form1();
        //            }
        //        }
        //        return instance;
        //    }
        //}


        private Form1()
        {
            InitializeComponent();
        }

        public static Form1 Instance { get { return Nested.instance; } }

        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly Form1 instance = new Form1();
        }


        private void evLoad(object sender, EventArgs e)
        {
            // TODO: 이 코드는 데이터를 'dBDataSet.phone' 테이블에 로드합니다. 필요한 경우 이 코드를 이동하거나 제거할 수 있습니다.
            this.phoneTableAdapter.Fill(this.dBDataSet.phone);

            tbLocalIp.Text = Util.Instance.getclientIp;

            Database.Instance.select_lvinit();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //HttpServer
            
            if (btStartAndStop)
            {
                Threads.Instance.ThreadStart();
                button1.Text = "중지";
                btStartAndStop = !btStartAndStop;

                //HttpServerMain 포트 넣어서 웹서버 돌림 포트는 이론상 0~65535
                //HttpServerMain.Instance.Start(int.Parse(tbPort.Text));

                tbPort.ReadOnly = true;
                listView2.Clear();
            }
            else
            {
                Threads.Instance.ThreadStop(false);
                button1.Text = "시작";
                btStartAndStop = !btStartAndStop;

                //HttpServerMain.Instance.Stop();

                tbPort.ReadOnly = false;
            }

        }

        private void Form1Closing(object sender, FormClosingEventArgs e)
        {
            if (!btStartAndStop)
            {
                Threads.Instance.ThreadStop(true);
                button1.Name = "시작";

                HttpServerMain.Instance.Stop();
            }
        }

        private void evKeyPress_PortFilter(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true; 
            }            
        }

        private void phoneBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.phoneBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dBDataSet);

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            //Database.Instance.update_phonenumber(new object[] { "12","352454053189216"});
            //Database.Instance.select_lvinit();

            listView2.Items[0].SubItems[2].Text = DateTime.Now.ToLocalTime().ToShortDateString() + DateTime.Now.ToLocalTime().ToShortTimeString();
        }   
     



    }
}
