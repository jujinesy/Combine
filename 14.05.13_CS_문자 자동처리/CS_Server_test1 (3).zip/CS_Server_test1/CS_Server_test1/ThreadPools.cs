﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Threading;

namespace SimpleHttp
{
    class ThreadPools
    {
        private ThreadPools()
        {
        }

        public static ThreadPools Instance { get { return Nested.instance; } }

        private class Nested
        {
            // Explicit static constructor to tell C# compiler
            // not to mark type as beforefieldinit
            static Nested()
            {
            }

            internal static readonly ThreadPools instance = new ThreadPools();
        }


        public Queue<WorkItem> queue;

        public void Process()
        {
            ThreadPool.QueueUserWorkItem(new WaitCallback(ProcessWorkItem));
        }

        private void ProcessWorkItem(object ignore)
        {
            if (this.queue.Count <= 0)
                return;

            //WorkItem item = this.queue.dequeue();
            //item.Execute();
            WorkItem item = this.queue.Dequeue();
            item.Execute();
            ThreadPool.QueueUserWorkItem(new WaitCallback(ProcessWorkItem));
            //queue.Enqueue(WorkItem Execute());
            
        }
    }

    public class WorkItem
    {
        public void Execute()
        {
        }
    }
}
