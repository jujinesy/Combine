//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TrayICON.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TRAYICON_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDI_ICON2                       130
#define IDR_ICON2                       130
#define IDR_MENU_TRAYPOPUP              131
#define IDR_ICON1                       133
#define ID_MENUITEM_ABOUT               32775
#define ID_MENUITEM_SHOWDLG             32776
#define ID_MENUITEM_AUTORUN             32777
#define ID_MENUITEM_PROGEXIT            32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
