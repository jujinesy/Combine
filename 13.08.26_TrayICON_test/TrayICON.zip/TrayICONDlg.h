// TrayICONDlg.h : ��� ����
//

#pragma once


// CTrayICONDlg ��ȭ ����
class CTrayICONDlg : public CDialog
{
// ����
public:
	BOOL SHRegReadString(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue, LPCTSTR lpDefault, LPTSTR lpRet, DWORD nSize);
	BOOL SHRegWriteString(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue, LPCTSTR lpData);
	BOOL SHRegDeleteValue(HKEY hKey, LPCTSTR lpKey, LPCTSTR lpValue);
	void SetRestoreFromTray();
	void SetMinimizeToTray();







	CTrayICONDlg(CWnd* pParent = NULL);	// ǥ�� ������
	
// ��ȭ ���� ������
	enum { IDD = IDD_TRAYICON_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����
	

// ����
protected:
	HICON m_hIcon;
	LRESULT OnTrayIconClick(WPARAM wParam, LPARAM lParam);
	LRESULT OnRestartTraybar(WPARAM wParam, LPARAM lParam);

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();


	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMenuitemAutorun();
	afx_msg void OnMenuitemAbout();
	afx_msg void OnMenuitemProgexit();
	afx_msg void OnMenuitemShowdlg();
	DECLARE_MESSAGE_MAP()
public:
};
