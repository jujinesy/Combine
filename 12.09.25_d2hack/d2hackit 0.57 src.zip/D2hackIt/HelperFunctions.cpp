/////////////////////////////////////////////////////////////////////////////
// D2HackItHelperFunctions.cpp
// --------------------------------------------------------------------------
//
// Helper functions for D2HackIt.dll
// 
// <thohell@home.se>
/////////////////////////////////////////////////////////////////////////////
#define THIS_IS_SERVER
#include "..\D2HackIt.h"

/////////////////////////////////////////////////////////////////////////////
// overloaded memcpy()
// --------------------------------------------------------------------------
// Takes care of giving the regions of memory the righ access rights needed
// when copying blocks of data.
/////////////////////////////////////////////////////////////////////////////
VOID* PRIVATE d2memcpy(DWORD lpDest, DWORD lpSource, int len)
{
	DWORD oldSourceProt,oldDestProt=0;
	 VirtualProtect((void*)lpSource,len,PAGE_EXECUTE_READWRITE,&oldSourceProt);
 	  VirtualProtect((void*)lpDest,len,PAGE_EXECUTE_READWRITE,&oldDestProt);
	   memcpy((void*)lpDest,(void*)lpSource,len);
	  VirtualProtect((void*)lpDest,len,oldDestProt,&oldDestProt);
	 VirtualProtect((void*)lpSource,len,oldSourceProt,&oldSourceProt);
	return (void*)lpDest;
};

/////////////////////////////////////////////////////////////////////////////
// Intercept()
// --------------------------------------------------------------------------
// Intercepts a code location to route it somewhere else.
// Also inserts original code at the destination.
/////////////////////////////////////////////////////////////////////////////
BOOL EXPORT Intercept(int instruction, DWORD lpSource, DWORD lpDest, int len)
{
	char t[1024];
	sprintf(t,"Code at %.8x intercepted and routed to %.8x",lpSource,lpDest);
	fep->GamePrintVerbose(t);

	BYTE* buffer = new BYTE[len];
	buffer[0] = instruction;
	*(DWORD*) (buffer + 1) = lpDest - (lpSource + 5);
	memset(buffer + 5, 0x90, len - 5);		// nops
	d2memcpy(lpDest, lpSource, len);		// Patch in old code to new location
	d2memcpy(lpSource, (DWORD) buffer, len);// Route old location to new
	delete buffer;
	return TRUE;
}
