//////////////////////////////////////////////////////////////////////
// TickThread.cpp
// -------------------------------------------------------------------
// Tick that calls modules approximatly every 1/10th of a second. 
// Great for implementing timers in modules.
//
// <thohell@home.se>
//////////////////////////////////////////////////////////////////////
#include "..\D2HackIt.h"


DWORD WINAPI TickThread(LPVOID lpParameter)
{
	LinkedList *cl=(LinkedList*)lpParameter;

	for (;;)
	{
		LinkedItem *li=cl->GetFirstItem();
		for(int i=0; i != cl->GetItemCount(); i++)
		{	
			CLIENTINFOSTRUCT *cds=(CLIENTINFOSTRUCT*)li->lpData;
			if (cds->OnGameTimerTick)
				cds->OnGameTimerTick();
			li=ClientList.GetNextItem(li);
		}
		Sleep(100);
	}
	
	// Dummy!
	return 0;
}

