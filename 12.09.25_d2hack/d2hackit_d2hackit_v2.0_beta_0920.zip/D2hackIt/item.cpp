//#include "stdafx.h"
#include "item.h"
#include "BitFields.h"
#include "properties.h"
#include "itemsize.h"

///////////////////////////////////////////////
// Item Mod Parsing, by Ackmed or Nuttzy
///////////////////////////////////////////////
BOOL __D2ParseMods(CBitFields &iPacket, ITEM& item)
{
	int temp;
	item.iModCount = 0;

	do
	{
		LPITEMMOD p= &item.aMods[item.iModCount];
		p->dwModID = iPacket.GetField(9);

		if(item.iModCount > 0)
		{
			if(p->dwModID < item.aMods[item.iModCount - 1].dwModID) 
			{
				item.iModCount = 0;
				return FALSE;
			}
		}

		if (p->dwModID == 511) 
			return TRUE;

		const D2_PROPERTIE* prop = GetPropertiesRow(p->dwModID);
		if(!prop)
			break;

		for (BYTE i = 0; i < prop->numFields; i++)
		{
			p->aValues[i] = iPacket.GetField(prop->bits[i]);
			p->aValues[i] -= prop->bias;
		}

		switch(p->dwModID)
		{
		case 48:
		case 50:
		case 52:
		case 54:
			p->iCount = 1;
			p->aValues[0] += p->aValues[1];
			break;

		case 57:
			p->iCount = 2;
			temp = (p->aValues[0] + p->aValues[1]) / 2;
			p->aValues[0] = (DWORD)(p->aValues[2] * 0.04);
			p->aValues[1] = temp * p->aValues[0] / 10;
			break;
			
		default:
			p->iCount = prop->numFields;
			break;
		}
		
		item.iModCount++;
	}while(item.iModCount < ITEM_MAX_MOD && iPacket.GetPos() + 9 < iPacket.GetMaxBits());

	return FALSE;
}

SIZE D2GetItemSize(LPCTSTR lpszItemCode)
{
	SIZE val = { 0 };
	if (lpszItemCode == NULL)
		return val;

	for (int i = 0; ITEM_SIZE_TB[i].code; i++)
	{
		if (stricmp(lpszItemCode, ITEM_SIZE_TB[i].code) == 0)
		{
			val.cx = ITEM_SIZE_TB[i].x;
			val.cy = ITEM_SIZE_TB[i].y;
			return val;
		}
	}

	return val;
}

BOOL IsPotion(const ITEM& item)
{
	return !stricmp(item.szItemCode, "rvl")
		|| !stricmp(item.szItemCode, "rvs")

		|| !stricmp(item.szItemCode, "hp1")
		|| !stricmp(item.szItemCode, "hp2")
		|| !stricmp(item.szItemCode, "hp3")
		|| !stricmp(item.szItemCode, "hp4")
		|| !stricmp(item.szItemCode, "hp5")

		|| !stricmp(item.szItemCode, "mp1")
		|| !stricmp(item.szItemCode, "mp2")
		|| !stricmp(item.szItemCode, "mp3")
		|| !stricmp(item.szItemCode, "mp4")
		|| !stricmp(item.szItemCode, "mp5");
}

int D2IsPotion(LPCSTR lpszItemCode)
{
	if (lpszItemCode == NULL)
		return POTION_UNKNOWN;
	
	if (!stricmp(lpszItemCode, "rvl")
		|| !stricmp(lpszItemCode, "rvs"))
		return POTION_PURPLE;

	if (!stricmp(lpszItemCode, "hp1")
		|| !stricmp(lpszItemCode, "hp2")
		|| !stricmp(lpszItemCode, "hp3")
		|| !stricmp(lpszItemCode, "hp4")
		|| !stricmp(lpszItemCode, "hp5"))
		return POTION_RED;

	if (!stricmp(lpszItemCode, "mp1")
		|| !stricmp(lpszItemCode, "mp2")
		|| !stricmp(lpszItemCode, "mp3")
		|| !stricmp(lpszItemCode, "mp4")
		|| !stricmp(lpszItemCode, "mp5"))
		return POTION_BLUE;

	if (!stricmp(lpszItemCode, "yps")
		|| !stricmp(lpszItemCode, "vps")
		|| !stricmp(lpszItemCode, "wms"))
		return POTION_JUNK;

	return POTION_UNKNOWN;
}

BOOL IsThrowItem(const ITEM& item)
{
	return !stricmp(item.szItemCode, "jav")
		|| !stricmp(item.szItemCode, "9ja")
		|| !stricmp(item.szItemCode, "7ja")

		|| !stricmp(item.szItemCode, "tax")
		|| !stricmp(item.szItemCode, "9ta")
		|| !stricmp(item.szItemCode, "7ta")

		|| !stricmp(item.szItemCode, "tkf")
		|| !stricmp(item.szItemCode, "9tk")
		|| !stricmp(item.szItemCode, "7tk")

		|| !stricmp(item.szItemCode, "am5")
		|| !stricmp(item.szItemCode, "ama")
		|| !stricmp(item.szItemCode, "amf")

		|| !stricmp(item.szItemCode, "pil")
		|| !stricmp(item.szItemCode, "9pi")
		|| !stricmp(item.szItemCode, "7pi")

		|| !stricmp(item.szItemCode, "bkf")
		|| !stricmp(item.szItemCode, "9bk")
		|| !stricmp(item.szItemCode, "7bk")

		|| !stricmp(item.szItemCode, "bal")
		|| !stricmp(item.szItemCode, "9b8")
		|| !stricmp(item.szItemCode, "7b8")

		|| !stricmp(item.szItemCode, "glv")
		|| !stricmp(item.szItemCode, "9gl")
		|| !stricmp(item.szItemCode, "7gl")

		|| !stricmp(item.szItemCode, "tsp")
		|| !stricmp(item.szItemCode, "9ts")
		|| !stricmp(item.szItemCode, "7ts");
}

BOOL D2GetItemCode(const BYTE* aPacket, DWORD aLen, LPTSTR szBuffer)
{
	if (aPacket == NULL || aLen < 19 || szBuffer == NULL)
		return FALSE;

	::memset(szBuffer, 0, (ITEM_CODE_LEN + 1) * sizeof(char));
	if(aPacket[0] != 0x9c && aPacket[0] != 0x9d)
		return FALSE;

	CBitFields iPacket(aPacket,aLen);	
	iPacket.GetField((aPacket[0] == 0x9d) ? 164 : 124);

	szBuffer[0] = (char)iPacket.GetField(8);
	szBuffer[1] = (char)iPacket.GetField(8);
	szBuffer[2] = (char)iPacket.GetField(8);
	return strlen(szBuffer) == ITEM_CODE_LEN;
}

///////////////////////////////////////////////
// Item Data Parsing, by Ackmed (or Nuttzy?)
///////////////////////////////////////////////
BOOL D2ParseItem(const BYTE *aPacket, DWORD aLen, ITEM& item)
{
	::memset(&item, 0 ,sizeof(ITEM));
	if (aPacket[0] != 0x9c && aPacket[0] != 0x9d)
		return FALSE;
	
	CBitFields iPacket(aPacket,aLen);	

	item.iMessageID = (BYTE)iPacket.GetField(8);//message
	item.iAction = (BYTE)iPacket.GetField(8);
	iPacket.GetField(8);//message size
	item.iType = (BYTE)iPacket.GetField(8);
	item.dwItemID = iPacket.GetField(32);

	if (aPacket[0] == 0x9d)
		iPacket.GetField(40); // for 0x9d

	if (aPacket[1] == ITEM_ACTION_TO_BELTSLOT
		|| aPacket[1] == ITEM_ACTION_FROM_BELTSLOT
		|| aPacket[1] == ITEM_ACTION_SWITCH_BELTSLOT)
	{
		// determine column & row
		item.iAtBeltRow = (((aPacket[14] % 32) - (aPacket[14] % 8)) / 8) % 4;
		item.iAtBeltColumn = ((aPacket[14] % 8) / 2) % 4;
	}
	else if (aPacket[1] == ITEM_ACTION_SHIFT_BELTSLOT)
	{
		// determine column & row
		item.iAtBeltRow = (((aPacket[19] % 32) - (aPacket[19] % 8)) / 8) % 4;
		item.iAtBeltColumn = ((aPacket[19] % 8) / 2) % 4;
	}

	item.iIsSocketFull = (BYTE)iPacket.GetField(1);
	iPacket.GetField(3);
	item.iIdentified = (BYTE)iPacket.GetField(1);
	iPacket.GetField(1);
	item.iSwtichIn = (BYTE)iPacket.GetField(1);
	item.iSwitchOut = (BYTE)iPacket.GetField(1);
	item.iBroken = (BYTE)iPacket.GetField(1);
	iPacket.GetField(2);
	BOOL bSocketed = iPacket.GetField(1);
	iPacket.GetField(4);

	BOOL bIsEar = (BOOL)iPacket.GetField(1);
	iPacket.GetField(5);
	item.iEthereal = (BYTE)iPacket.GetField(1);
	iPacket.GetField(1);

	item.iPersonalized = (BYTE)iPacket.GetField(1);
	item.iGamble = (BYTE)iPacket.GetField(1);
	item.iRuneword = (BYTE)iPacket.GetField(1);
	iPacket.GetField(15);
	item.iLocation = (BYTE)iPacket.GetField(3);

	if(aPacket[1] == ITEM_ACTION_DROP || aPacket[1] == ITEM_ACTION_NEW_GROUND || aPacket[1] == ITEM_ACTION_OLD_GROUND)
	{
		item.wPositionX = (WORD)iPacket.GetField(16);
		item.wPositionY = (WORD)iPacket.GetField(16);
	}
	else
	{
		iPacket.GetField(4);
		item.wPositionX = (WORD)iPacket.GetField(4);
		item.wPositionY = (WORD)iPacket.GetField(4);
		item.iStorageID = (BYTE)iPacket.GetField(3);
	}

	if (bIsEar)
		return TRUE;

	item.szItemCode[0] = (char)iPacket.GetField(8);
	item.szItemCode[1] = (char)iPacket.GetField(8);
	item.szItemCode[2] = (char)iPacket.GetField(8);
	item.szItemCode[3] = '\0';
	iPacket.GetField(8);
	
	if (!stricmp(item.szItemCode, "gld"))
	{
		if(iPacket.GetField(1))
			item.dwGoldAmount = iPacket.GetField(32);
		else
			item.dwGoldAmount = iPacket.GetField(12);
		return TRUE;
	}

	if (   !stricmp(item.szItemCode, "ibk")
		|| !stricmp(item.szItemCode, "tbk")
		|| !stricmp(item.szItemCode, "key")
		|| !stricmp(item.szItemCode, "box")
		|| !stricmp(item.szItemCode, "cqv")
		|| !stricmp(item.szItemCode, "aqv"))
	{
		return TRUE;
	}

	// packet not long enough to read ItemLevel
	if(iPacket.GetPos() + 14 >= iPacket.GetMaxBits())
		return TRUE;

	iPacket.GetField(3);
	item.iLevel = (BYTE)iPacket.GetField(7);
	item.iQuality = (BYTE)iPacket.GetField(4);

	BOOL flag1 = iPacket.GetField(1);
	BOOL flag2 = iPacket.GetField(1);

	if(flag1)//ring amu charm jew
	{
		iPacket.GetField(3);
	}
	else if(flag2)
	{
		iPacket.GetField(11);
	}

	int pos_begin = iPacket.GetPos();

///////////////////////////////////////////
	int retry_time=0;
RE_TRY:
	iPacket.SetCurPos(pos_begin);
///////////////////////////////////////////

	if(item.iIdentified)
	{
		switch(item.iQuality)
		{
		case ITEM_LEVEL_MAGIC:
			/*item.wMagicPrefix = (BYTE)*/iPacket.GetField(11);
			/*item.wMagicSuffix = (BYTE)*/iPacket.GetField(11);
			break;
			
		case ITEM_LEVEL_UNIQUE:
			/*item.wUniqueID = (WORD)*/iPacket.GetField(12);
			break;

		case ITEM_LEVEL_SET:
			/*item.wSetID = (WORD)*/iPacket.GetField(12);
			break;

		case ITEM_LEVEL_SUPERIOR:
			iPacket.GetField(3);
			break;

		case ITEM_LEVEL_RARE:
		case ITEM_LEVEL_CRAFT:
			/*item.wMagicPrefix=(WORD)*/iPacket.GetField(8)/* - 155*/;
			/*item.wMagicSuffix =(WORD)*/iPacket.GetField(8);
			if (!item.iIdentified)
				return TRUE;

			/////////////////////////////////////////////
			// ��һ�β�֪����ʲô���壬����Ҳ���̶�
			
			iPacket.GetField(6);
			const int rcskip[]={3,4,5,2,6,7,1,8,9};
			for (int i = 0; i < rcskip[retry_time]; i++)
			{
				iPacket.GetField(11);
			}
			/////////////////////////////////////////////
			break;
			
		}
	}

	if (item.iRuneword)
	{
		iPacket.GetField(16);
	}

	//��������
	if(item.iType ==ITEM_ITEMTYPE_ARMOR
		||item.iType==ITEM_ITEMTYPE_HELM
		||item.iType==ITEM_ITEMTYPE_SHIELD
		||item.iType==ITEM_ITEMTYPE_EXPANSION
		||item.iType==ITEM_ITEMTYPE_OTHER && !flag1)
	{
		item.wDefense = (WORD)(iPacket.GetField(11) - 10);
	}


	if(IsThrowItem(item))
	{
		iPacket.GetField(9);
		iPacket.GetField(17);
	}
	else if(!stricmp(item.szItemCode, "7cr")) //phase blade
	{
		iPacket.GetField(8);
	}
	else if(item.iType ==ITEM_ITEMTYPE_BOW)
	{
		iPacket.GetField(17);
	}
	else if(!flag1)
	{
		item.wDurability = (WORD)iPacket.GetField(8);
		item.wMaxDurability = (WORD)iPacket.GetField(8);
		iPacket.GetField(1);
	}

	if(bSocketed)
		item.iSocketNumber = (BYTE)iPacket.GetField(4);

	if (!item.iIdentified)
		return TRUE;

	if (item.iQuality == ITEM_LEVEL_SET)
	{
		iPacket.GetField(5);
	}

	BOOL bModOK=__D2ParseMods(iPacket, item);

	///////////////////////////////////////////////////
	if(!bModOK)
	{
		if((item.iQuality==ITEM_LEVEL_RARE
			||item.iQuality==ITEM_LEVEL_CRAFT)
			&&retry_time<9)
		{
			item.wDefense = 0;
			item.wMaxDurability = 0;
			item.wDurability = 0;
			item.iSocketNumber = 0;
			retry_time++;
			goto RE_TRY;
		}
	}
	///////////////////////////////////////////////////

	return TRUE;
}

BOOL D2GetItemMod(const ITEM& item, DWORD dwModID, LPITEMMOD pMod)
{
	if (pMod)
		::memset(pMod, 0, sizeof(ITEMMOD));
	if (dwModID >= 511)
		return FALSE;

	for (BYTE i = 0; i < item.iModCount; i++)
	{
		if (item.aMods[i].dwModID == dwModID && item.aMods[i].iCount > 0)
		{
			if (pMod)
				::memcpy(pMod, &item.aMods[i], sizeof(ITEMMOD));
			return TRUE;
		}
	}

	return FALSE;
}

BYTE D2GetBeltRows(LPCTSTR lpszItemCode)
{
	if (lpszItemCode == NULL)
		return 0;

	if (stricmp(lpszItemCode, "lbl") == 0 // sash
		|| stricmp(lpszItemCode, "vbl") == 0) // light belt
		return 2;
	else if (stricmp(lpszItemCode, "mbl") == 0 // belt
		|| stricmp(lpszItemCode, "tbl") == 0) // heavy belt
		return 3;
	else if (stricmp(lpszItemCode, "hbl") == 0 // plated belt
		|| stricmp(lpszItemCode, "zlb") == 0 // demonhide sash
		|| stricmp(lpszItemCode, "zvb") == 0 // sharkskin belt
		|| stricmp(lpszItemCode, "zmb") == 0 // mesh belt
		|| stricmp(lpszItemCode, "ztb") == 0 // battle belt
		|| stricmp(lpszItemCode, "zhb") == 0 // war belt
		|| stricmp(lpszItemCode, "ulc") == 0 // Spiderweb Sash
		|| stricmp(lpszItemCode, "uvc") == 0 // Vampirefang Belt
		|| stricmp(lpszItemCode, "umc") == 0 // Mithril Coil
		|| stricmp(lpszItemCode, "utc") == 0 // Troll Belt
		|| stricmp(lpszItemCode, "uhc") == 0) // Colossus Girdle
		return 4;
	else
		return 0;
}

DWORD D2ItemCode2Dword(LPCTSTR lpszItemCode) // convert a string into dword
{
	if (lpszItemCode == NULL)
		return 0;

	DWORD dw = 0;
	::memcpy(&dw, lpszItemCode, ITEM_CODE_LEN);
	return dw;
}