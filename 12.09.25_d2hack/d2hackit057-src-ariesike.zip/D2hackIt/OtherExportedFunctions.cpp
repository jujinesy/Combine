//////////////////////////////////////////////////////////////////////
// OtherExportedFunctions.cpp
// -------------------------------------------------------------------
// Misc. stuff that doesn't really go anywhere else.
//
// <thohell@home.se>
//////////////////////////////////////////////////////////////////////
#define THIS_IS_SERVER
#include "..\D2HackIt.h"

PTHISGAMESTRUCT EXPORT GetThisgameStruct(void)
{
	return thisgame;
}