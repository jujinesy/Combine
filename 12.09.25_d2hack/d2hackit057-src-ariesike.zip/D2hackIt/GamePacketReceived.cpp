//////////////////////////////////////////////////////////////////////
// GamePacketReceived.cpp
// -------------------------------------------------------------------
// All hooks have a 'stub' and a 'clean' c version. I did this to be
// able to update the stub when new patches come out without having to
// change anything in the clean code. Once in the clean code, we don't
// need to worry about registers/stack etc.etc.
//
// <thohell@home.se>
//////////////////////////////////////////////////////////////////////
#define THIS_IS_SERVER
#include "..\D2HackIt.h"


//////////////////////////////////////////////////////////////////////
// GamePacketReceived()
// -------------------------------------------------------------------
// Our 'clean' GamePacketReceived()
//////////////////////////////////////////////////////////////////////
DWORD __fastcall GamePacketReceivedIntercept(BYTE* aPacket, DWORD aLength)
{
	DWORD aReturnValue=1;

	// Pass packet to all clients who wants to snoop
	LinkedItem *li=ClientList.GetFirstItem();
	CLIENTINFOSTRUCT* cds;
	for(int i=0; i<ClientList.GetItemCount(); i++)
	{	
		cds=(CLIENTINFOSTRUCT*)li->lpData;
		if (cds->OnGamePacketBeforeReceived)
			if (!cds->OnGamePacketBeforeReceived(aPacket, aLength))
				aReturnValue=0;
		li=ClientList.GetNextItem(li);
	}
	return aReturnValue;
}

//////////////////////////////////////////////////////////////////////
// GamePacketReceivedSTUB()
// -------------------------------------------------------------------
// ebx = packet number
// ebp = pointer to packet		(Needed)
// edi = length
// eax = length
// ecx = length					(Needed)
// edx = ebx * 3				(Needed)
//////////////////////////////////////////////////////////////////////
void __declspec(naked) GamePacketReceivedInterceptSTUB()
{
	__asm {
		nop									// Make room for original code
		nop
		nop
		nop
		nop
		nop
		nop

		pushad

		// Call our clean c function
		mov edx, ecx
		mov ecx, ebp
		call GamePacketReceivedIntercept

		// Return 0?, if so send dummy packet.
		cmp eax, 0
		je  dummy

		// Return to game
		popad
		ret
		
dummy:	// Send dummy packet (0x77, 0x06);
		popad
		mov word ptr [ebp], 0x0677		// 7706 packet
		mov ecx, 2						// 2 bytes long
		mov edx, 0x165					// 0x77 * 3 = 0165
		ret
	}
}

