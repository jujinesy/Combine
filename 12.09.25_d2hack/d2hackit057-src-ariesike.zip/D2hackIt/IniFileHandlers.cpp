//////////////////////////////////////////////////////////////////////
// IniFileHandlers.cpp
// -------------------------------------------------------------------
// Functions used for manipulating .ini files.
//
// <thohell@home.se>
//////////////////////////////////////////////////////////////////////
#define THIS_IS_SERVER
#include "..\D2HackIt.h"

//////////////////////////////////////////////////////////////////////
// GetHackProfileString
// -------------------------------------------------------------------
// Reads a whole profile section using GetPrivateProfileString().
// Remember that this function uses 'new char[]' to create a return
// value the application. This means it should be unitialized when 
// calling this functions. You also need to manually delete it when 
// you are done with the data if you plan on using the variable again.
//
// Failing to do this *WILL* result in memory leaks!
//////////////////////////////////////////////////////////////////////
LPSTR EXPORT GetHackProfileString(LPCSTR lpHackName, LPCSTR lpSectionName, LPCSTR lpKeyName)
{
	LPSTR lpFileName = new char[strlen(si->PluginDirectory)+strlen(lpHackName)+6];
	sprintf (lpFileName, "%s\\%s.ini", si->PluginDirectory, lpHackName);
	LPCSTR lpDefault="";
	LPSTR  lpReturnedString;

	// Check if the file exists
	if (_access(lpFileName, 0))
	{ 
		char t[1024];
		sprintf(t, "Unable to open ini-file: �c4%s", lpFileName);
		fep->GamePrintError(t);
		delete lpFileName;
		return NULL;
	}

	// Try getting the data in 1924-byte increments
	DWORD  alloc=0;
	DWORD  allocStep = 1024;

	while (TRUE)
	{
		alloc+=allocStep;
		lpReturnedString = new char[alloc];
		if (GetPrivateProfileString(lpSectionName, lpKeyName, lpDefault, lpReturnedString, alloc, lpFileName) != strlen(lpReturnedString)+1)
			break;
		delete lpReturnedString;
	}
	delete lpFileName;
	return lpReturnedString;
}



//////////////////////////////////////////////////////////////////////
// SetHackProfileString
// -------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////
BOOL EXPORT SetHackProfileString(LPCSTR lpHackName, LPCSTR lpSectionName, LPCSTR lpKeyName, LPCSTR lpValue)
{
	LPSTR lpFileName = new char[strlen(si->PluginDirectory)+strlen(lpHackName)+6];
	sprintf (lpFileName, "%s\\%s.ini", si->PluginDirectory, lpHackName);
	LPCSTR lpDefault="";

	// Check if the file exists
	if (_access(lpFileName, 0))
	{ 
		char t[1024];
		sprintf(t, "Unable to open ini-file: �c4%s", lpFileName);
		fep->GamePrintError(t);
		delete lpFileName;
		return FALSE;
	}

	WritePrivateProfileString(lpSectionName, lpKeyName, lpValue, lpFileName);
	delete lpFileName;
	return TRUE;
}


//////////////////////////////////////////////////////////////////////
// GetFingerPrint
// -------------------------------------------------------------------
// Reads szFingerPrintName from the [FingerprintData] section of the
// ini-file asociated with szHackName.
// 
// It breaks up the components of the string, does some basic sanity-
// check and calls GetMemoryAddressFromPattern() to store the address
// of the fingerprint, if found.
//////////////////////////////////////////////////////////////////////
BOOL EXPORT GetFingerprint(LPCSTR szHackName, LPCSTR szFingerprintName, FINGERPRINTSTRUCT &fps)
{
	LPSTR szReturnString;
	sprintf(fps.Name, szFingerprintName);
	fps.AddressFound=0;

	int i;
	int nFields=0;
	char *t;
	szReturnString=fep->GetHackProfileString(szHackName, "FingerprintData", szFingerprintName);
	

	// No such fingerprint!
	if (!strlen(szReturnString))
	{ 
		t=new char[256];
		sprintf(t, "Can't find fingerprint for '%s' in '%s.ini'",
			szFingerprintName, szHackName);
		fep->GamePrintError(t);
		delete t, szReturnString; 
		return FALSE;
	}


	// Make sure we have 4 fields
	for (i=0; szReturnString[i]; i++)
		if (szReturnString[i] == ',')
			nFields++;

	if (nFields != 3)
	{ 
		t=new char[256];
		sprintf(t, "Fingerprint for '%s' in '%s.ini' is corrupt.",
			szFingerprintName, szHackName);
		fep->GamePrintError(t);
		delete t, szReturnString; 
		return FALSE;
	}


	// Loop backwards to get fingerprint info
	for (;i!=0;i--)
	{
		if (szReturnString[i] == ',')
		{
			szReturnString[i] = 0;
			nFields--;
			switch (nFields)
			{
			case 2:
				strcpy(fps.FingerPrint, &szReturnString[i+1]);
				break;
			case 1:
				fps.Offset=atoi(&szReturnString[i+1]);
				break;
			case 0:
				fps.PatchSize=atoi(&szReturnString[i+1]);
				break;
			}
		}
	}
	strcpy(fps.ModuleName, szReturnString);
	delete szReturnString;


	if ((fps.AddressFound=GetMemoryAddressFromPattern(fps.ModuleName, fps.FingerPrint, fps.Offset)) < 0x100)
	{
		if (psi->DontShowErrors)
			return FALSE;

		t=new char[256];
		sprintf(t, "Unable fo find location for '%s'.",
			szFingerprintName, szHackName);
		fep->GamePrintError(t);
		delete t;
		return FALSE;
	} else {
		t=new char[256];
		sprintf(t, "Found '%s' at %.8x",
			szFingerprintName, fps.AddressFound);
		fep->GamePrintVerbose(t);
		delete t;
		return TRUE;
	}
}
