#include "stdafx.h"
#include "CamTest.h"
#include "CamTestDlg.h"
#include "math.h"

#define pi 3.141592f;

extern LPBYTE lpDataDouble;
extern int ptstack[5];
extern BOOL target_detected[5];
extern int target_str[4];
extern pointHF* points[5];
extern float lie;
extern unsigned char* lp[10];


BOOL **pMap[5];


BOOL ImgProc(LPBYTE lpdata,int w, int h,int procType)
{

	if(procType==0)
	{
		pointExtract(lpdata,h,w,0);

		target_str[0]=  (pointMatch(1,90,0.001));
		target_str[1]=  (pointMatch(2,90,0.001));
		target_str[2]=  (pointMatch(3,90,0.001));
		target_str[3]=  (pointMatch(4,90,0.001));

		for(int i=0;i<ptstack[0];i++)
		{
			lpdata[(points[0][i].y*w+points[0][i].x)*3+2]=255;
			lpdata[(points[0][i].y+1*w+points[0][i].x)*3+2]=255;
			lpdata[(points[0][i].y-1*w+points[0][i].x)*3+2]=255;
			lpdata[(points[0][i].y*w+points[0][i].x+1)*3+2]=255;
			lpdata[(points[0][i].y*w+points[0][i].x-1)*3+2]=255;

		}
	}
	else if(procType==1)
	{
		
		pointExtract(lpdata,h,w,0);

		target_str[0]=  (pointMatch(1,0.001,0.8));
		target_str[1]=  (pointMatch(2,0.01,0.8));
		target_str[2]=  (pointMatch(3,0.1,0.8));
		target_str[3]=  (pointMatch(4,0.5,0.8));

		
		/*
		for(int i=0;i<ptstack[1];i++)
		{
			for(int a=-points[1][i].scale;a<points[1][i].scale+1;a++)
				for(int b=-points[1][i].scale;b<points[1][i].scale+1;b++)
					lpdata[((points[1][i].y+a)*w+points[1][i].x+b)*3]=255;
		}
		*/
		
		
		for(int i=0;i<ptstack[0];i++)
		{
			//lpdata[(points[0][i].y*w+points[0][i].x)*3+2]=255;
			for(int a=-points[0][i].scale;a<points[0][i].scale+1;a++)
				for(int b=-points[0][i].scale;b<points[0][i].scale+1;b++)
					lpdata[((points[0][i].y+a)*w+points[0][i].x+b)*3+2]=255;
		}

	}
	return TRUE;

}
BOOL pointExtract(unsigned char* lpdata, int h, int w,int target)
{
	int i,j,oc=3,intervals=3;
	float edge,lo,ar;
	int dxx,dyy,dxy;
	int* sumImg;
	int *hImg[3];

	unsigned char* gray;
	gray = new unsigned char[h*w];

	for(i=0; i<h; i++)
		for(j=0; j<w; j++)
			gray[i*w+j]=(unsigned char)((lpdata[(i*w+j)*3]+lpdata[(i*w+j)*3+1]+lpdata[(i*w+j)*3+2])/3);
	
	hImg[0] = new int[h*w];
	hImg[1] = new int[h*w];
	hImg[2] = new int[h*w];

	sumImg = new int [h*w];

	int val, scale;
	BOOL mget;
	int object=target;

	pMap[object] = new BOOL* [h];
	for(i=0;i<h;i++){
		pMap[object][i] = new BOOL[w];
		for(j=0;j<w;j++)
			pMap[object][i][j]=FALSE;
	}

	for(i=0;i<h;i++)
		for(j=0;j<w;j++)
		{
			hImg[0][i*w+j]=0;
			hImg[1][i*w+j]=0;
			hImg[2][i*w+j]=0;
		}
	sumImg[0] = gray[0];
	for(j=1;j<w; j++) 
		sumImg[j] = sumImg[j-1]+gray[j];
	for(i=1;i<h; i++)
		sumImg[i*w]=sumImg[(i-1)*w]+gray[i*w];
	for(i=1; i<h; i++)
		for(j=1;j<w; j++) 
			sumImg[i*w+j] = sumImg[(i-1)*w+j]+sumImg[i*w+j-1]+gray[i*w+j]-sumImg[(i-1)*w+j-1];

	for(int o=0; o<oc;o++)
	{
		edge = (3*pow(2.0f,o+1)*(intervals)+1)/2;
		for(int k=0; k<intervals; k++)
		{
			lo = pow(2.0f,o+1)*(k+1)+1;

			ar = pow((3*lo),2);

			for(int i=edge; i<h-edge; i++)
			{
				for(int j=edge; j<w-edge;j++)
				{
					if (o==1){
						dyy=pGet(sumImg,i+4,j+2,i-5,j-3,w)-3*pGet(sumImg,i+2,j+1,i-3,j-2,w);
						dxx=pGet(sumImg,i+2,j+4,i-3,j-5,w)-3*pGet(sumImg,i+1,j+2,i-2,j-3,w);
						dxy=pGet(sumImg,i+3,j+3,i,j,w)+pGet(sumImg,i-1,j-1,i-4,j-4,w)
							-pGet(sumImg,i+3,j-1,i,j-4,w)-pGet(sumImg,i-1,j+3,i-4,j,w);
						hImg[0][i*w+j]=(dxx*dyy-0.81*dxy*dxy)/ar;
					}
					else if(o==2){					
						dxx=pGet(sumImg,i+4,j+7,i-5,j-8,w)-3*pGet(sumImg,i+4,j+2,i-5,j-3,w);
						dyy=pGet(sumImg,i+7,j+4,i-8,j-5,w)-3*pGet(sumImg,i+2,j+4,i-3,j-5,w);
						dxy=pGet(sumImg,i+5,j+5,i,j,w)+pGet(sumImg,i-1,j-1,i-6,j-6,w)
							-pGet(sumImg,i+5,j-1,i,j-6,w)-pGet(sumImg,i-1,j+5,i-6,j,w);
						hImg[1][i*w+j]=(dxx*dyy-0.81*dxy*dxy)/ar;	
					}
					else if(o==3){
						dyy=pGet(sumImg,i+10,j+6,i-11,j-7,w)-3*pGet(sumImg,i+3,j+6,i-4,j-7,w);
						dxx=pGet(sumImg,i+6,j+10,i-7,j-11,w)-3*pGet(sumImg,i+6,j+3,i-7,j-4,w);
						dxy=pGet(sumImg,i+7,j+7,i,j,w)+pGet(sumImg,i-1,j-1,i-8,j-8,w)
							-pGet(sumImg,i+7,j-1,i,j-8,w)-pGet(sumImg,i-1,j+7,i-8,j,w);
						hImg[2][i*w+j]=(dxx*dyy-0.81*dxy*dxy)/ar;
					}
				}
			}
		}
	}

	
	
	ptstack[0]=0;
	for(i=17;i<h-17;i++)
		for(j=17;j<w-17;j++)
		{
			mget=TRUE;
			if (hImg[0][(i*w+j)]>500)
			{
				for(int k=-1;k<2;k++)
					for(int l=-1;l<2;l++)
						if ((((k!=0) || (l!=0))&&(hImg[0][(i+k)*w+j+l]>hImg[0][(i*w+j)]))||((hImg[1][(i+k)*w+j+l]>hImg[0][(i*w+j)])))
								mget=FALSE;

				if (mget)
				{					
					points[object][ptstack[object]].x = j;
					points[object][ptstack[object]].y = i;
					pMap[object][i][j]=TRUE;
					points[object][ptstack[object]].scale = 1;
					ptstack[object]++;
				}
			}
		}
	for(i=24;i<h-24;i++)
		for(j=24;j<w-24;j++)
		{
			mget=TRUE;
			if (hImg[1][(i*w+j)]>500)
			{
				for(int k=-1;k<2;k++)
					for(int l=-1;l<2;l++)
						if ((((k!=0) || (l!=0))&&(hImg[1][(i+k)*w+j+l]>hImg[1][(i*w+j)]))
							||((hImg[0][(i+k)*w+j+l]>hImg[1][(i*w+j)]))
							||((hImg[2][(i+k)*w+j+l]>hImg[1][(i*w+j)])))
							mget=FALSE;

				if (mget)
				{					
					points[object][ptstack[object]].x = j;
					points[object][ptstack[object]].y = i;
					pMap[object][i][j]=TRUE;
					points[object][ptstack[object]].scale = 2;
					ptstack[object]++;
				}
			}
		}
	for(i=30;i<h-30;i++)
		for(j=30;j<w-70;j++)
		{
			mget=TRUE;
			if (hImg[2][(i*w+j)]>500)
			{
				for(int k=-1;k<2;k++)
					for(int l=-1;l<2;l++)
						if ((((k!=0) || (l!=0))&&(hImg[2][(i+k)*w+j+l]>hImg[2][(i*w+j)]))||((hImg[1][(i+k)*w+j+l]>hImg[2][(i*w+j)])))
							mget=FALSE;

				if (mget)
				{					
					points[object][ptstack[object]].x = j;
					points[object][ptstack[object]].y = i;
					pMap[object][i][j]=TRUE;
					points[object][ptstack[object]].scale = 3;
					ptstack[object]++;
				}
			}
		}

	int dx=0,dy=0,dxa=0,dya=0;
	float hVal,min,angle;
	float rv,gv,bv;
	int sc;
	for(int k = 0; k<ptstack[object];k++)
	{		
		sc = points[object][k].scale;

		int directionX=0,directionY=0;
		float direction;
		for(int a=-6*sc;a<=6*sc;a+=sc)
			for(int b=-6*sc;b<=6*sc;b+=sc)
				if((a*a+b*b)<36*sc*sc)
					if (pMap[object][points[object][k].y+a][points[object][k].x+b])
					{
						directionX+=a;
						directionY+=b;
					}
		direction =directionX==0? 1.570796f : atan((float)(directionY/directionX));
		points[object][k].orien = direction;

		points[object][k].dEx=0;
		points[object][k].dEy=0;
		points[object][k].dExa=0;
		points[object][k].dEya=0;

		for(int m=0;m<4;m++)
			for(int n=0;n<4;n++)	
			{
				points[object][k].dxS[m][n]=0;
				points[object][k].dyS[m][n]=0;
				points[object][k].dxaS[m][n]=0;
				points[object][k].dyaS[m][n]=0;
				for(int a=0;a<5;a++)
					for(int b=0;b<5;b++)
					{
						int v= points[object][k].y +m*5-10+a;
						int u= points[object][k].x +n*5-10+b;
						dx=pGet(sumImg,v+4*sc,u+4*sc,v,u+2*sc,w)
							-pGet(sumImg,v+4*sc,u+2*sc,v,u,w);
						dy=pGet(sumImg,v+2*sc,u+4*sc,v,u,w)
							-pGet(sumImg,v+4*sc,u+4*sc,v+2*sc,u,w);
						dxa=abs(dx);
						dya=abs(dy);
						points[object][k].dxS[m][n]+=dx;
						points[object][k].dyS[m][n]+=dy;
						points[object][k].dxaS[m][n]+=dxa;
						points[object][k].dyaS[m][n]+=dya;
					}
				
				points[object][k].dir[m][n]= points[object][k].dxS[m][n]>0? 1.570796f:atan(points[object][k].dyS[m][n]/points[object][k].dxS[m][n]);
				points[object][k].dira[m][n]= points[object][k].dxaS[m][n]>0? 1.570796f:atan(points[object][k].dyaS[m][n]/points[object][k].dxaS[m][n]);
				points[object][k].dir[m][n]-=points[object][k].orien;
				points[object][k].dira[m][n]-=points[object][k].orien;
				if (points[object][k].dir[m][n]<0)
					points[object][k].dir[m][n]+=2*pi;
				if (points[object][k].dira[m][n]<0)
					points[object][k].dira[m][n]+=2*pi;
				points[object][k].dxR[m][n]=cos(points[object][k].dir[m][n])*points[object][k].dxS[m][n]/sc/sc/11;
				points[object][k].dyR[m][n]=sin(points[object][k].dir[m][n])*points[object][k].dxS[m][n]/sc/sc/11;
				points[object][k].dxaR[m][n]=cos(points[object][k].dira[m][n])*points[object][k].dxaS[m][n]/sc/sc/11;
				points[object][k].dyaR[m][n]=cos(points[object][k].dira[m][n])*points[object][k].dyaS[m][n]/sc/sc/11;
				
				points[object][k].dxF[(int)floor((m-1.5)*cos(direction)+(n-1.5)*sin(direction)+0.5)][(int)floor((n-1.5)*cos(direction)-(m-1.5)*sin(direction)+0.5)]=points[object][k].dxR[m][n];
				points[object][k].dyF[(int)floor((m-1.5)*cos(direction)+(n-1.5)*sin(direction)+0.5)][(int)floor((n-1.5)*cos(direction)-(m-1.5)*sin(direction)+0.5)]=points[object][k].dyR[m][n];
				points[object][k].dxaF[(int)floor((m-1.5)*cos(direction)+(n-1.5)*sin(direction)+0.5)][(int)floor((n-1.5)*cos(direction)-(m-1.5)*sin(direction)+0.5)]=points[object][k].dxaR[m][n];
				points[object][k].dyaF[(int)floor((m-1.5)*cos(direction)+(n-1.5)*sin(direction)+0.5)][(int)floor((n-1.5)*cos(direction)-(m-1.5)*sin(direction)+0.5)]=points[object][k].dyaR[m][n];
				points[object][k].dEx +=  points[object][k].dxS[m][n];
				points[object][k].dEy +=  points[object][k].dyS[m][n];
				points[object][k].dExa +=  points[object][k].dxaS[m][n];
				points[object][k].dEya +=  points[object][k].dyaS[m][n];
			}
		
	}

		
	
	//for(int k=0;k<ptstack[target];k++)
	
	delete [] hImg[0];
	delete [] hImg[1];
	delete [] hImg[2];

	delete [] sumImg;

	delete []gray;

	return TRUE;
};
int pGet(int* sumImg, int h0, int w0, int h1, int w1,int w)
{
	return sumImg[h0*w+w0]+sumImg[h1*w+w1]-sumImg[h0*w+w1]-sumImg[h1*w+w0];
}
int pointMatch(int target,int thresh,float rate)
{
	int i,j,k,l,sum,score=0;

	float min,smn,cal;
	float sigma;

	for(i=0;i<ptstack[target];i++)
	{
		//6.283184f
		//min = 2147483647;
		//smn = 1073741824;
		
		for(j=0;j<ptstack[0];j++)
		{		

			sigma = 0;

			sigma+=abs(points[0][j].dEx*points[0][j].dEx-points[target][i].dEx*points[target][i].dEx);
			sigma+=abs(points[0][j].dEy*points[0][j].dEy-points[target][i].dEy*points[target][i].dEy);
			sigma+=abs(points[0][j].dExa*points[0][j].dExa-points[target][i].dExa*points[target][i].dExa);
			sigma+=abs(points[0][j].dEya*points[0][j].dEya-points[target][i].dEya*points[target][i].dEya);	
			
			if (sigma <500000000)
			{
				score++;
				break;
			}
			

			/*
			sigma = 0;
			for(k=0;k<4;k++)
				for(l=0;l<4;l++)
				{
					sigma+=sqrt(abs(points[0][j].dxF[k][l]*points[0][j].dxF[k][l]-points[target][i].dxF[k][l]*points[target][i].dxF[k][l]));
					sigma+=sqrt(abs(points[0][j].dyF[k][l]*points[0][j].dyF[k][l]-points[target][i].dyF[k][l]*points[target][i].dyF[k][l]));
					sigma+=sqrt(abs(points[0][j].dxaF[k][l]*points[0][j].dxaF[k][l]-points[target][i].dxaF[k][l]*points[target][i].dxaF[k][l]));
					sigma+=sqrt(abs(points[0][j].dyaF[k][l]*points[0][j].dyaF[k][l]-points[target][i].dyaF[k][l]*points[target][i].dyaF[k][l]));	
				}

			if (sigma<min)
				min=sigma;
			else if (sigma <smn)
				smn=sigma;
			*/
		}
		//if (min*2<smn)//*2<smn)//&&(min<500))
		//{
		//	score++;
		//}
	}
	return score;
}