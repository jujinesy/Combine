
// CamTestDlg.h : ��� ����
//

#pragma once
//#pragma comment(lib,"vfw32.lib")
#include "vfw.h"
#include "resource.h"

struct pointHF
{
	int x,y,scale;
	float dxS[4][4],dyS[4][4],dxaS[4][4],dyaS[4][4];
	float dxSS[4][4],dySS[4][4],dxaSS[4][4],dyaSS[4][4];
	float dir[4][4],dira[4][4];
	float dxR[4][4],dyR[4][4],dxaR[4][4],dyaR[4][4];
	float dxF[4][4],dyF[4][4],dxaF[4][4],dyaF[4][4];
	float dEx,dEy,dExa,dEya;
	float orien;
	float descriptor[64];
};

// CCamTestDlg ��ȭ ����
class CCamTestDlg : public CDialogEx
{
	// �����Դϴ�.
public:
	CCamTestDlg(CWnd* pParent = NULL);	// ǥ�� �������Դϴ�.

	// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_CAMTEST_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �����Դϴ�.


	// �����Դϴ�.
protected:
	HICON m_hIcon;

	// ������ �޽��� �� �Լ�
	virtual BOOL OnInitDialog();
	BOOL DoubleInit();

	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	HWND m_hWndCap;
	HWND m_hWndCapProc;
	afx_msg void OnDestroy();
};
LRESULT CALLBACK capCallbackOnFrame(HWND hWnd, LPVIDEOHDR lpVHdr);
int pGet(int* sumImg, int h0, int w0, int h1, int w1,int w);
int pointMatch(int target,int thresh,float rate);
BOOL pointExtract(unsigned char* lpdata, int h, int w,int target);
BOOL ImgProc(LPBYTE lpdata,int w, int h,int procType);