#include "stdafx.h"
#include "FileSpy.h"

#include "FileSpyDoc.h"
#include "FileSpyView.h"

#include <process.h>
#include <afxmt.h>
#include <AFXPRIV.H>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileSpyView

CListCtrl* pList;
CListCtrl* pList1;

CCriticalSection m_Sec;

IMPLEMENT_DYNCREATE(CFileSpyView, CFormView)

BEGIN_MESSAGE_MAP(CFileSpyView, CFormView)
	//{{AFX_MSG_MAP(CFileSpyView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileSpyView construction/destruction

CFileSpyView::CFileSpyView()
	: CFormView(CFileSpyView::IDD)
{
	//{{AFX_DATA_INIT(CFileSpyView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CFileSpyView::~CFileSpyView()
{
}

void CFileSpyView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFileSpyView)
	DDX_Control(pDX, IDC_LIST2, m_List1);
	DDX_Control(pDX, IDC_LIST1, m_List);
	//}}AFX_DATA_MAP
}

BOOL CFileSpyView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void ThreadRoute( void* arg )	
	{
	HANDLE file;
	file = FindFirstChangeNotification("c:\\Program Files", FALSE, (DWORD)((Param*)arg)->parameter);
	WaitForSingleObject(file, INFINITE);

	CTime tm = CTime::GetCurrentTime();
	m_Sec.Lock();
	int item = pList->InsertItem(pList->GetItemCount(), ((Param*)arg)->message);
	pList->SetItemText(item, 1, tm.Format("%Y/%m/%d - %H:%M:%S"));
	m_Sec.Unlock();

	while (true)
		{
		FindNextChangeNotification(file);
		WaitForSingleObject(file, INFINITE);
		tm = CTime::GetCurrentTime();
		m_Sec.Lock();
		int item = pList->InsertItem(pList->GetItemCount(), ((Param*)arg)->message);
		pList->SetItemText(item, 1, tm.Format("%Y/%m/%d/ - %H:%M:%S"));
		m_Sec.Unlock();
		}
  FindCloseChangeNotification(file);
	}

void ThreadRoute1( void* arg )	
	{
  USES_CONVERSION;

  HANDLE hDir = CreateFile( CString("c:\\Program Files"), // pointer to the file name
    FILE_LIST_DIRECTORY,                // access (read/write) mode
    FILE_SHARE_READ|FILE_SHARE_DELETE,  // share mode
    NULL,                               // security descriptor
    OPEN_EXISTING,                      // how to create
    FILE_FLAG_BACKUP_SEMANTICS,         // file attributes
    NULL                                // file with attributes to copy
  );

  FILE_NOTIFY_INFORMATION Buffer[1024];
  DWORD BytesReturned;
  while( ReadDirectoryChangesW(
                                hDir,                                  // handle to directory
                                &Buffer,                                    // read results buffer
                                sizeof(Buffer),                                // length of buffer
                                TRUE,                                 // monitoring option
                                FILE_NOTIFY_CHANGE_SECURITY|
                                FILE_NOTIFY_CHANGE_CREATION|
                                FILE_NOTIFY_CHANGE_LAST_ACCESS|
                                FILE_NOTIFY_CHANGE_LAST_WRITE|
                                FILE_NOTIFY_CHANGE_SIZE|
                                FILE_NOTIFY_CHANGE_ATTRIBUTES|
                                FILE_NOTIFY_CHANGE_DIR_NAME|
                                FILE_NOTIFY_CHANGE_FILE_NAME,             // filter conditions
                                &BytesReturned,              // bytes returned
                                NULL,                          // overlapped buffer
                                NULL// completion routine
                                ))
    {
		CTime tm = CTime::GetCurrentTime();

    CString helper_txt;
    
    switch(Buffer[0].Action)
      {
      case FILE_ACTION_ADDED: helper_txt = "The file was added to the directory"; break; 
      case FILE_ACTION_REMOVED: helper_txt = "The file was removed from the directory"; break; 
      case FILE_ACTION_MODIFIED: helper_txt = "The file was modified. This can be a change in the time stamp or attributes."; break; 
      case FILE_ACTION_RENAMED_OLD_NAME: helper_txt = "The file was renamed and this is the old name."; break; 
      case FILE_ACTION_RENAMED_NEW_NAME: helper_txt = "The file was renamed and this is the new name."; break;
      }
    int i=0;
    do
      {
      m_Sec.Lock();
      int item = pList1->InsertItem(pList1->GetItemCount(), CString(Buffer[i].FileName).Left(Buffer[i].FileNameLength / 2) + " - " + helper_txt );
		  pList1->SetItemText(item, 1, tm.Format("%Y/%m/%d/ - %H:%M:%S"));
      i++;
      m_Sec.Unlock();
      }
    while (!Buffer[i].NextEntryOffset);
    }
	}

void CFileSpyView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	pList = &m_List;
  pList1 = &m_List1;

  m_List.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	m_List.InsertColumn(0, CString("Event monitored uses Find ... ChangeNotification"), LVCFMT_LEFT, 100, 0 );
	m_List.InsertColumn(1, CString("Date/Time occured"), LVCFMT_LEFT, 100, 1 );

  m_List1.InsertColumn(0, CString("Event monitored uses ReadDirectoryChangesW"), LVCFMT_LEFT, 100, 0 );
	m_List1.InsertColumn(1, CString("Date/Time occured"), LVCFMT_LEFT, 100, 1 );


	_beginthread( ThreadRoute, 0, (void*)new Param(FILE_NOTIFY_CHANGE_FILE_NAME, CString("FILE_NOTIFY_CHANGE_FILE_NAME") ) );

	_beginthread( ThreadRoute, 0, (void*)new Param(FILE_NOTIFY_CHANGE_DIR_NAME, "FILE_NOTIFY_CHANGE_DIR_NAME" ) );

	_beginthread( ThreadRoute, 0, (void*)new Param(FILE_NOTIFY_CHANGE_DIR_NAME, "FILE_NOTIFY_CHANGE_DIR_NAME" ) );

	_beginthread( ThreadRoute, 0, (void*)new Param(FILE_NOTIFY_CHANGE_ATTRIBUTES, "FILE_NOTIFY_CHANGE_ATTRIBUTES" ) );
	
	_beginthread( ThreadRoute, 0, (void*)new Param(FILE_NOTIFY_CHANGE_SIZE, "FILE_NOTIFY_CHANGE_SIZE" ) );

	_beginthread( ThreadRoute, 0, (void*)new Param(FILE_NOTIFY_CHANGE_LAST_WRITE, "FILE_NOTIFY_CHANGE_LAST_WRITE" ) );

	_beginthread( ThreadRoute, 0, (void*)new Param(FILE_NOTIFY_CHANGE_SECURITY, "FILE_NOTIFY_CHANGE_SECURITY" ) );

  _beginthread( ThreadRoute1, 0, 0 );

}

/////////////////////////////////////////////////////////////////////////////
// CFileSpyView printing

BOOL CFileSpyView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CFileSpyView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CFileSpyView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CFileSpyView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CFileSpyView diagnostics

#ifdef _DEBUG
void CFileSpyView::AssertValid() const
{
	CFormView::AssertValid();
}

void CFileSpyView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CFileSpyDoc* CFileSpyView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFileSpyDoc)));
	return (CFileSpyDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFileSpyView message handlers

void CFileSpyView::OnDraw(CDC* pDC) 
  {
	CRect rect;
  GetClientRect(rect);
  rect.bottom = rect.bottom - rect.Height() / 2;
	m_List.MoveWindow(rect);
	m_List.SetColumnWidth(0, rect.Width() / 2);
	m_List.SetColumnWidth(1, rect.Width() / 2);

  GetClientRect(rect);
  rect.top = rect.top + rect.Height() / 2;
  m_List1.MoveWindow(rect);
	m_List1.SetColumnWidth(0, rect.Width() / 2);
	m_List1.SetColumnWidth(1, rect.Width() / 2);
  }
