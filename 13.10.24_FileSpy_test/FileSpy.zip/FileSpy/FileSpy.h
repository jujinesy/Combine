// ==========================================================================
// 
// Author : Vitali Halershtein
//          vitali2001by@yahoo.co.uk
//
// Last Modified : 7.09.2003
// by            : Vitali Halershtein
// Copyright  :
// This software is released into the public domain. You are free to use it in any way you like.
// You should save Author text in the header files. If you modify it or extend it, please consider 
// posting new code here for everyone to share. This software is provided "as is" with no 
// expressed or implied warranty. I accept no liability for any damage or loss of business
// that this software may cause. 
// ==========================================================================


#if !defined(AFX_FILESPY_H__3A95B3E6_8733_4DE6_AD05_F019EDC751B4__INCLUDED_)
#define AFX_FILESPY_H__3A95B3E6_8733_4DE6_AD05_F019EDC751B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFileSpyApp:
// See FileSpy.cpp for the implementation of this class
//

class CFileSpyApp : public CWinApp
{
public:
	CFileSpyApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileSpyApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CFileSpyApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILESPY_H__3A95B3E6_8733_4DE6_AD05_F019EDC751B4__INCLUDED_)
