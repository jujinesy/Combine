// ==========================================================================
// 
// Author : Vitali Halershtein
//          vitali2001by@yahoo.co.uk
//
// Last Modified : 7.09.2003
// by            : Vitali Halershtein
// Copyright  :
// This software is released into the public domain. You are free to use it in any way you like.
// You should save Author text in the header files. If you modify it or extend it, please consider 
// posting new code here for everyone to share. This software is provided "as is" with no 
// expressed or implied warranty. I accept no liability for any damage or loss of business
// that this software may cause. 
// ==========================================================================
// FileSpyView.h : interface of the CFileSpyView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILESPYVIEW_H__48BA74F2_A508_4316_B409_A4360D1094C9__INCLUDED_)
#define AFX_FILESPYVIEW_H__48BA74F2_A508_4316_B409_A4360D1094C9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct Param
	{
	Param(DWORD param, LPCTSTR mess)
		{
		parameter = param;
		message = mess;
		};
	DWORD parameter;
	CString message;
	};

class CFileSpyView : public CFormView
{
protected: // create from serialization only
	CFileSpyView();
	DECLARE_DYNCREATE(CFileSpyView)

public:
	//{{AFX_DATA(CFileSpyView)
	enum { IDD = IDD_FILESPY_FORM };
	CStatic	m_s1;
	CStatic	m_s;
	CListCtrl	m_List1;
	CListCtrl	m_List;
	//}}AFX_DATA

// Attributes
public:
	CFileSpyDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileSpyView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFileSpyView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFileSpyView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in FileSpyView.cpp
inline CFileSpyDoc* CFileSpyView::GetDocument()
   { return (CFileSpyDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

void ThreadRoute( void* arg );


#endif // !defined(AFX_FILESPYVIEW_H__48BA74F2_A508_4316_B409_A4360D1094C9__INCLUDED_)
